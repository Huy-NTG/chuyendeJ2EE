package com.example.backend.repository;

public interface TextEmbeddingRepository {
}
