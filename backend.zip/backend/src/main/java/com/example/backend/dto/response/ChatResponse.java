package com.example.backend.dto.response;

import java.util.List;

public class ChatResponse {
    public String answer;
    public List<SearchResult> context;
}
